<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body><span>for my self. home work</span><hr />
<h1>Курс валют по РФ</h1>

<?PHP
echo $cours;
?>	
<br /><br /><br />SOAP server www.cbr.ru<br />
<pre>
© Банк России, 2000–2019
Адрес: ул. Неглинная, 12, Москва, 107016

Телефоны: 8 800 300-30-00 (для бесплатных звонков из регионов России),
+7 499 300-30-00 (круглосуточно), факс: +7 495 621-64-65
</pre>
<hr />
<h2>Task1</h2>
<h3>Class: SoapTest - XML/WSDL</h3><br/>
<?PHP
echo "<img src=".$arr['sCountryFlag']." alt=\"flag\" width=\"50px\" /><br />";
foreach($arr as $k=>$v)
{
	echo "$k = $v<br />";
}
?>
<hr />
</body>
</html>