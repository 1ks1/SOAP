<?PHP
class SOAP
{
    public $url;
    public $client;
    public $date;
    public $result;
    public $euro_to;
    public $euro_from;
    public $one_uan_of_ru;

    function __construct($url)
    {
        $this->client = new SoapClient( 
            $url,
            array( 'soap_version'=> SOAP_1_2, 
            'exceptions'=>true));

        $this->date = $this->client->GetLatestDateTime();
        $this->result = $this->client->GetCursOnDateXML(array('On_date'=>$this->date->GetLatestDateTimeResult));
    }
    

    function test()
    {
        return 'OK';
    }

    function getONEUANEURUSD()
    {
        $eu;
        $us;
        $zl;
        $result = $this->client->GetCursOnDateXML(array('On_date'=>$this->date->GetLatestDateTimeResult));
        if ($result->GetCursOnDateXMLResult->any) 
        {
            $xml = new SimpleXMLElement($result->GetCursOnDateXMLResult->any);
            foreach ($xml->ValuteCursOnDate as $currency) 
            {
                if ($currency->VchCode == 'UAH') 
                {
                    $a = floatval($currency->Vcurs);
                    $b = $currency->Vnom;
                    $this->one_uan_of_ru = ($currency->Vcurs/$currency->Vnom);
                }

                if ($currency->VchCode == 'PLN') 
                {
                    $a = floatval($currency->Vcurs);
                    $b = $currency->Vnom;
                    $zl = ($currency->Vcurs/$currency->Vnom);
                }

                if ($currency->VchCode == 'EUR') 
                {
                    $a = floatval($currency->Vcurs);
                    $b = $currency->Vnom;
                    $eu = ($currency->Vcurs/$currency->Vnom);
                }

                if ($currency->VchCode == 'USD') 
                {
                    $a = floatval($currency->Vcurs);
                    $b = $currency->Vnom;
                    $us = $a/$b;

                    //гривну разделить на курс рубля и умножить на бакс
                    //$us = floatval((1/$this->one_uan_of_ru) * $c);
                }
            }
            return "1 RUB = " . 
            round(1/$this->one_uan_of_ru,2) . "UAH <br /> 1 USD = " . 
            round($us/$this->one_uan_of_ru,2) . "UAH<br /> 1 EUR  " . 
            round($eu/$this->one_uan_of_ru,2) . " UAH <br />" . 
            "1 PLN = " . round($zl/$this->one_uan_of_ru,2) . "UAH";
        }
        else return false;
    }
}