<?PHP
include('libs/SOAP.php');
include('libs/SoapTest.php');
///for my self
$cl = new SOAP('http://www.cbr.ru/DailyInfoWebServ/DailyInfo.asmx?WSDL');
$cours = $cl->getONEUANEURUSD();

///FOR TASK1//////////////////////
$cltest = new SoapTest;
$url = 'http://webservices.oorsprong.org/websamples.countryinfo/CountryInfoService.wso?WSDL';

$paramArr = [];
$param['sCountryISOCode']='RU';
// $paramArr[] = $param;
// $paramArr[] = array();
$data = $cltest->test($url,$param);

$arr = [];
$arr['sCapitalCity'] = $data->FullCountryInfoResult->sCapitalCity;
$arr['sName'] = $data->FullCountryInfoResult->sName;
$arr['sCurrencyISOCode'] = $data->FullCountryInfoResult->sCurrencyISOCode;
$arr['sCountryFlag'] = $data->FullCountryInfoResult->sCountryFlag;
///////////CURL///////////////
$res = $cltest->test2($url,['sCountryISOCode'=>'UA']);
echo "<pre>";
var_dump($res);
echo "</pre>";
include('templates/index.php');