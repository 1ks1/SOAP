<?PHP
//Calss: AutoShop
//Model
include ('Db.php');

class AutoShop extends Db
{
    function allAuto()
    {
      $q  = 'SELECT cars.id,cars.model,brands.brand FROM cars,brands ';
      $q .= 'WHERE brands.id = brand_id';
      $res = $this->query($q);
      return $res;
    }

    function oneAuto($id)
    {
      if (is_numeric($id) && (0 < $id))
      {
        $q = 'SELECT cars.model modelname,cars.id ID,cars.year,engines.value engine,colors.color,cars.maxspeed,cars.price 
        FROM cars,colors,engines 
        WHERE engine_id = engines.id and colors.id = color_id and cars.id =' . $id;
        $res = $this->query($q);
      }else{$res = ['0'=>['Server:'=>'Error! id is not numeric or  0']];}
      return $res;
    }

    function showOrder($user)
    {
        //Показываем типа заказ
       //ID авто, имя, фамилия покупателя, способ оплаты.
      $user = $this->valid($user);
      if ((!empty($user)) && (3 < strlen($user)))
      {
          $q = 'select orders.car_id CAR_ID,users.name Name,users.lastname Lastname,payments.payment PAYMENT 
          from orders,payments,users 
          where (users.id = orders.user_id and payments.id = orders.payment_id) 
          AND users.name=' . "'$user'";
          $res = $this->query($q);
          if (0 == count($res))
          $res = ['0'=>['Server:'=>'No such user ' . $user]];
      }else{
        return ['0'=>['Server:'=>'User name is not valid']];
      }
      return $res;
    }


    function valid($text)
    {
      $text = htmlspecialchars(trim($text));
      return strip_tags($text);
    }


    function searchAuto($type)
    {
      if (isset($type['year']) && is_numeric($type['year']))
      { 
        //год обязательно, ищем в паре с 'модель' или частично

        $cq = 'SELECT cars.id,cars.model,cars.year,engines.value engine,colors.color,cars.maxspeed,cars.price ' . 
        'FROM cars ' .
        'INNER JOIN engines ON engines.id=engine_id ' . 
        'INNER JOIN colors ON colors.id = color_id';

        $y = $type['year'];
        if (isset($type['model']) && strlen($type['model']) > 1)
        {
          $dq = 'SELECT * FROM (' . $cq . ") AS A WHERE model LIKE '%" . 
          $type['model'] . "%' AND $y=year GROUP BY id";
        }
        else 
        {
          $dq = 'SELECT * FROM (' . $cq . ") AS A WHERE $y=year GROUP BY id";
        }

        if (strlen($dq)<1)
        $dq = $cq;

        $q = $dq;
        $r = $this->query($q);

    
        //сортируем массивы по параметрам
        //если задан цвет
        if (isset($type['color']) && strlen($type['year'])>1)
        {
          $arr2 = [];
            foreach ($r as $k=>$v)
            { 
              $c1 = strtolower(($v['color']));
              $c2 = strtolower(trim($type['color']));
              if ($c1 == $c2)
              $arr2[] = $v;
            }
          $r = $arr2;
        }

        //если двиг задан, выберем диаппазон "до значения"
        if (isset($type['engine']) && strlen($type['engine'])>1)
        {
          $arr2 = [];
            foreach ($r as $k=>$v)
            { 
              $c1 = strtolower(($v['engine']));
              $c2 = strtolower(trim($type['engine']));
              if (($c1 <= $c2) && ($c1 ))
              $arr2[] = $v;
            }
          if (! 0 == (integer)strtolower(trim($type['engine'])))
          $r = $arr2;
        }

        //если cкорость задано, выберем диаппазон "до значения"
        if (isset($type['maxspeed']) && strlen($type['maxspeed'])>1)
        {
          $arr2 = [];
            foreach ($r as $k=>$v)
            { 
              $c1 = strtolower(($v['maxspeed']));
              $c2 = strtolower(trim($type['maxspeed']));
              if ($c1 <= $c2)
              $arr2[] = $v;
            }
          if (! 0 == (integer)strtolower(trim($type['maxspeed'])))
          $r = $arr2;
        }

        //если цена задано, выберем диаппазон "до значения"
        if (isset($type['price']) && strlen($type['price'])>1)
        {
          $arr2 = [];
            foreach ($r as $k=>$v)
            { 
              $c1 = strtolower(($v['price']));
              $c2 = strtolower(trim($type['price']));
              if ($c1 <= $c2)
              $arr2[] = $v;
            }
          if (! 0 == (integer)strtolower(trim($type['price'])))
          $r = $arr2;
        }
        


        $count = count($r);
        if (1 > $count)
        return 'Server:Sorry. Not found for this parameters';

        return $r;
      }
      else
      {
        return 'Server:Error. year example: [2006]';
      }
    }


}