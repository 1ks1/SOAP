<?PHP
//Calss: AutoShop
//Model
include ('Db.php');

class AutoShop extends Db
{
    function allAuto()
    {
      $q  = 'SELECT cars.id,cars.model,brands.brand FROM cars,brands ';
      $q .= 'WHERE brands.id = brand_id';
      $res = $this->query($q);
      return $res;
    }

    function oneAuto($id)
    {
      if (is_numeric($id) && (0 < $id))
      {
        $q = 'SELECT cars.model modelname,cars.id ID,cars.year,engines.value engine,colors.color,cars.maxspeed,cars.price 
        FROM cars,colors,engines 
        WHERE engine_id = engines.id and colors.id = color_id and cars.id =' . $id;
        $res = $this->query($q);
      }else{$res = ['0'=>['Server:'=>'Error! id is not numeric or  0']];}
      return $res;
    }

    function showOrder($user)
    {
        //Показываем типа заказ
       //ID авто, имя, фамилия покупателя, способ оплаты.
      $user = $this->valid($user);
      if ((!empty($user)) && (3 < strlen($user)))
      {
          $q = 'select orders.car_id CAR_ID,users.name Name,users.lastname Lastname,payments.payment PAYMENT 
          from orders,payments,users 
          where (users.id = orders.user_id and payments.id = orders.payment_id) 
          AND users.name=' . "'$user'";
          $res = $this->query($q);
          if (0 == count($res))
          $res = ['0'=>['Server:'=>'No such user ' . $user]];
      }else{
        return ['0'=>['Server:'=>'User name is not valid']];
      }
      return $res;
    }


    function valid($text)
    {
      $text = htmlspecialchars(trim($text));
      return strip_tags($text);
    }


    function searchAuto($type)
    {
      if (isset($type['year']) && is_numeric($type['year']))
      { 
        // $bq = '';
        // $aq  = 'SELECT cars.id,cars.model,cars.year,engines.value engine,colors.color,cars.maxspeed,cars.price ';
        // $aq .= ' FROM cars,engines,colors ' ; 
        // $aq .= ' WHERE (engine_id=engines.id and colors.id = color_id) ';
        // $aq .= ' and ';
        // $aq .= ' year=' . $type['year'];

 

        

  
        $cq = 'SELECT cars.id,cars.model,cars.year,engines.value engine,colors.color,cars.maxspeed,cars.price ' . 
        'FROM cars ' .
        'INNER JOIN engines ON engines.id=engine_id ' . 
        'INNER JOIN colors ON colors.id = color_id';
        

        foreach ($type as $k=>$v)
        {
            $k = $this->valid($k);
            $v = $this->valid($v);
            $model = '';
            switch ($k) 
            {
              case 'model':  
                  if (strlen($v) > 0)
                  $model = " and model LIKE '%$v%' ";

                  break;
              case 'price':
                  //$q .= " and price < $v";
                  break;
              case 'maxspeed':
                  //$q .= " and maxspeed < $v";
                  break;
              case 'engine':
                  //$q .= " and engin.value < $v";
                  break;
              case 'color':
                  //$q .= " and color LIKE '%$v%'";
                  break;
            }         
        }
  
        $cq = 'SELECT cars.id,cars.model,cars.year,engines.value engine,colors.color,cars.maxspeed,cars.price ' . 
        'FROM cars ' .
        'INNER JOIN engines ON engines.id=engine_id ' . 
        'INNER JOIN colors ON colors.id = color_id WHERE year=' . $type['year'] . $model;

        print_r($cq);



        //$q .= ')';
        $q = $cq;
        $r = $this->query($q);
        $r2 = [];
        // foreach($r as $v)
        // {
        //   print_r($v['model']);
        // }

        

        $count = count($r);
        if (1 > $count)
        return 'Server:Sorry. Not found for this parameters';

        return $r;
      }
      else
      {
        return 'Server:Error. year example: [2006]';
      }
    }


}