<?PHP
//Calss:Db


include ('dbconfig.php');

class Db
{
    protected function connect()
    {
        $dsn = "mysql:host=" . HOST . ";dbname=" . DB . ";charset=" . CHARSET;
        $user = USER;
        $password = PASSWORD;
        $opt = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false
        ];

        try{
            $pdo = new PDO($dsn, $user, $password, $opt);
        }
        catch(PDOException $e) 
        {  
            return $e->getMessage();  
        }
        return $pdo;
    }

    function query($query)
    {
        if (!$con = $this->connect())
        return false;
        $stmt = $con->prepare($query);
        $stmt->execute();
        $row = $stmt->fetchAll();
        $res = array();
        foreach ($row as $r)
        {
            $res[] = $r;
        }
        return $res;
    }

}