<?PHP
#####################
## database config ##
#####################

define ('DB','user11');
define ('PASSWORD','user11');
define ('USER','user11');
define ('HOST','127.0.0.1');
define ('CHARSET','utf8');
// define ('PASSWORD','usbw');
// define ('USER','root');