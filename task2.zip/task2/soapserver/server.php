<?PHP
include('config.php');
include('Db.php');

ini_set("soap.wsdl_cache_enabled","0");
ini_set( 'soap.wsdl_cache_ttl', 0 );
//ini_set('always_populate_raw_post_data','-1');
date_default_timezone_set('Europe/Kiev');
//Header("Pragma: no-cache"); // HTTP/1.1 
//header('Content-Type: text/html; charset=utf-8');
//header('Cache-Control: no-store, no-cache');
//header('Expires: '.date('r'));


class AutoShop
{
    private $autoCatalog;
    private $con;
    
    public function show()
    {
      return $this->con;
    }

    function allAuto()
    {
        $db = new Db;
        $res = $db->select('SELECT cars.id,cars.model,brands.brand 
        FROM cars,brands 
        WHERE brands.id = brand_id');
        return $res;
    }

    function oneAuto($id)
    {
      if (is_numeric($id) && (0 < $id))
      {
        $db = new Db;
        $q = 'select cars.model modelname,cars.year,engin.value engine,colors.color,cars.maxspeed,cars.price 
        from cars,colors,engin 
        where engine_id=engin.id and colors.id = color_id and cars.id =' . $id;
        $res = $db->select($q);
      }else{$res = false;}
      return $res;
    }


    function valid($text)
    {
      $text = htmlspecialchars($text);
      return strip_tags($text);
    }


    function searchAuto($type)
    {
      
      if (isset($type['year']) && is_numeric($type['year']))
      {  
        $q = 'SELECT cars.model,cars.year,engin.value engine,colors.color,cars.maxspeed,cars.price ';
        $q .= ' FROM cars,engin,colors ' ; 
        $q .= ' WHERE (engine_id=engin.id and colors.id = color_id) ';
        $q .= ' and (';
        $q .= ' year=' . $type['year'];
        foreach ($type as $k=>$v)
        {
          switch ($k) 
          {
            case 'model':
                $q .= " and model LIKE '%$v%'";
                break;
            case 'price':
                $q .= " and price < $v";
                break;
            case 'maxspeed':
                $q .= " and maxspeed < $v";
                break;
            case 'engine':
                $q .= " and engin.value < $v";
                break;
            case 'color':
                $q .= " and color LIKE '%$v%'";
                break;
          }         
        }
        $q .= ') ';
        //return $q;
        $db = new Db;
        $r = $db->select($q);
        if (count($r) < 1)
        return 'Sorry. Not found for this parameters';
        return($db->select($q));
      }
      else
      {
        return ['error'=>'year example: [2006]'];
      }
    }




// class registerUsers {
//   function setData($name, $password, $email, $userType) 
//   {
//       $dbInfo = array(
//           'host' => 'localhost',
//           'user' => 'user11',
//           'pass' => 'user11',
//           'database' => 'user11'
//       );
//       if(empty($name) || empty($password) || empty($email) || empty($userType)) 
//       {
//           throw new SoapFault("Server", "Error! You must send all fields.");
//           exit;
//       }
//       $name = htmlspecialchars(trim($name));
//       $password = md5(htmlspecialchars(trim($password)));
//       $email = htmlspecialchars(trim($email));
//       $userType = htmlspecialchars(trim($userType));
//       $this->connect = new PDO ("mysql:host=localhost;dbname=user1;charset=utf8", 'user11', 'user11') ;
//       $sqlQuery = "INSERT INTO users_soap (name, password, email, userType) VALUES ('$name', '$password', '$email', '$userType')";
//       $result = $this->connect->query($sqlQuery) ;
//       return "Success! All data sent to database!";
//   }
//   function getUsers() {
//       $dbInfo = array(
//           'host' => 'localhost',
//           'user' => 'user11',
//           'pass' => 'user11',
//           'database' => 'user11'
//       );
//       $this->connect = new PDO ("mysql:host=localhost;dbname=user1;charset=utf8", 'user11', 'user11') ;
//       $sqlQuery = "SELECT name, email, userType FROM users_soap";
//       $result = $this->connect->query($sqlQuery);    
      
//       $resultArray = array ();
//   while ($row = $result->fetchAll(PDO::FETCH_OBJ) ) 
//   {
//     $resultArray[] = $row;
//       }
      
//       return $resultArray;
      
//   }
}



//$options= array('uri'=>'/home/user11/public_html/soap/task2/soapserver/');
//$options['soap_version'] = SOAP_1_1;
//$options['encoding'] = 'UTF-8';
//$options['location'] = '/home/user11/public_html/soap/task2/soapserverserver.php';

//$server = new SoapServer(null, $options));
//$server=new SoapServer(NULL);

// initialize SOAP Server
//$server=new SoapServer("test.wsdl",array(
//    'soap_version' => SOAP_1_1,
//    'style' => SOAP_RPC,
//    'use' => SOAP_LITERAL
//));

//$server->setClass('NewOperation');
// register available functions
//$server->addFunction('hello');
//$server->setClass('MyServer');

// start handling requests
//$server->handle();
//echo 'SOAP server';


$server = new SoapServer(URL,array('cache_wsdl' => WSDL_CACHE_NONE));
//$server->addFunction("sayHello");
$server->setClass("AutoShop");
ob_clean();
ob_start();
$server->handle();
//var_dump($server);