<?PHP
include('config.php');
include('Db.php');

ini_set("soap.wsdl_cache_enabled","0");
ini_set( 'soap.wsdl_cache_ttl', 0 );
//ini_set('always_populate_raw_post_data','-1');
date_default_timezone_set('Europe/Kiev');
//Header("Pragma: no-cache"); // HTTP/1.1 
//header('Content-Type: text/html; charset=utf-8');
//header('Cache-Control: no-store, no-cache');
//header('Expires: '.date('r'));


class AutoShop
{
    private $autoCatalog;
    private $con;
    
    public function show()
    {
      return $this->con;
    }

    function allAuto()
    {
        $db = new Db;
        $res = $db->select('SELECT cars.id,cars.model,brands.brand 
        FROM cars,brands 
        WHERE brands.id = brand_id');
        return $res;
    }

    function oneAuto($id)
    {
      if (is_numeric($id) && (0 < $id))
      {
        $db = new Db;
        $q = 'select cars.model modelname,cars.year,engin.value engine,colors.color,cars.maxspeed,cars.price 
        from cars,colors,engin 
        where engine_id=engin.id and colors.id = color_id and cars.id =' . $id;
        $res = $db->select($q);
      }else{$res = ['0'=>['Server:'=>'Error! id is not numeric or  0']];}
      return $res;
    }

    function showOrder($user)
    {
      
      //Показываем типа заказ
       //ID авто, имя, фамилия покупателя, способ оплаты.
       $user = $this->valid($user);
      if((!empty($user)) && (3 < strlen($user)))
      {
        $db = new Db;
        $q = 'select orders.car_id CAR_ID,users.name Name,users.lastname Lastname,payments.payment PAYMENT 
        from orders,payments,users 
        where (users.id = orders.user_id and payments.id = orders.payment_id) 
        AND users.name=' . "'$user'";
        $res = $db->select($q);
        if (0 == count($res))
        $res = ['0'=>['Server:'=>'No such user ' . $user]];
      }else{
        return ['0'=>['Server:'=>'User name is not valid']];
      }
      return $res;


    }


    function valid($text)
    {
      $text = htmlspecialchars(trim($text));
      return strip_tags($text);
    }


    function searchAuto($type)
    {
      
      if (isset($type['year']) && is_numeric($type['year']))
      {  
        $q = 'SELECT cars.model,cars.year,engin.value engine,colors.color,cars.maxspeed,cars.price ';
        $q .= ' FROM cars,engin,colors ' ; 
        $q .= ' WHERE (engine_id=engin.id and colors.id = color_id) ';
        $q .= ' and (';
        $q .= ' year=' . $type['year'];
        foreach ($type as $k=>$v)
        {
          $k = $this->valid($k);
          $v = $this->valid($v);
          switch ($k) 
          {
            case 'model':  
                $q .= " and model LIKE '%$v%'";
                break;
            case 'price':
                $q .= " and price < $v";
                break;
            case 'maxspeed':
                $q .= " and maxspeed < $v";
                break;
            case 'engine':
                $q .= " and engin.value < $v";
                break;
            case 'color':
                $q .= " and color LIKE '%$v%'";
                break;
          }         
        }
        $q .= ') ';
        
        $db = new Db;
        $r = $db->select($q);
        if (count($r) < 1)
        return 'Server:Sorry. Not found for this parameters';
        return($db->select($q));
      }
      else
      {
        return 'Server:Error. year example: [2006]';
      }
    }


}


$server = new SoapServer(URL,array('cache_wsdl' => WSDL_CACHE_NONE));
//$server->addFunction("sayHello");
$server->setClass("AutoShop");
ob_clean();
ob_start();
$server->handle();
