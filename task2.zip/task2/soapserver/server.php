<?PHP
include('config.php');
include('libs/AutoShop.php');

$server = new SoapServer(URL,array('cache_wsdl' => WSDL_CACHE_NONE));
$server->setClass("AutoShop");
ob_clean();
ob_start();
$server->handle();
