<?PHP
ini_set("soap.wsdl_cache_enabled","0");
//ini_set( 'soap.wsdl_cache_ttl', 0 );

class MyServer
{
	public $test='test var OK';
  
  public function test()
  {
    return 'Method TEST OK';
  }
}

header("Content-Type: text/html; charset=utf-8");
header('Cache-Control: no-store, no-cache');

$options= array('uri'=>'http://127.0.0.1/SOAP/task2/soapserver/server.php');
$options['soap_version'] = SOAP_1_1;
//$options['encoding'] = 'UTF-8';
$options['location'] = 'http://127.0.0.1/SOAP/task2/soapserver/server.php';

//$server = new SoapServer(null, $options));
//$server=new SoapServer(NULL);

// initialize SOAP Server
//$server=new SoapServer("test.wsdl",array(
//    'soap_version' => SOAP_1_1,
//    'style' => SOAP_RPC,
//    'use' => SOAP_LITERAL
//));

//$server->setClass('NewOperation');
// register available functions
//$server->addFunction('hello');
//$server->setClass('MyServer');

// start handling requests
//$server->handle();
//echo 'SOAP server';


function sayHello($fn = 'Guest')
{
    return 'Helo, ' . $fn;
}

$server = new SoapServer('test.wsdl');
$server->addFunction("sayHello");
$server->handle();
//var_dump($server);