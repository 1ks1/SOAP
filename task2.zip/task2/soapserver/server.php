<?PHP
include('Db.php');

ini_set("soap.wsdl_cache_enabled","0");
ini_set( 'soap.wsdl_cache_ttl', 0 );
header("Content-Type: text/html; charset=utf-8");
header('Cache-Control: no-store, no-cache');


class AutoShop extends Db
{
    private $autoCatalog;
    private $con;

    // public function __construct()
    // {
    //     $db = new Db;
    //     $this->con = $db->getConnection(); 
    // }

    public function show()
    {
      return $this->con;
    }

    function allAuto()
    {
        $resultArray = array();

        // foreach($this->con->query('SELECT Cars.id, CarsModel.name, model 
        // from Cars,CarsModel 
        // where id_name = CarsModel.id') as $row) {
        //     $tmp_arr = array('id'=>$row['id'],'model'=>$row['model'],'name'=>$row['name']);
        //     array_push($resultArray, $tmp_arr); 
        // }

        foreach($this->con->query('SELECT *from Cars') as $row) 
        {
            $tmp_arr = array('id'=>$row['id'],'model'=>$row['model'],'engine'=>$row['engine']);
            array_push($resultArray, $tmp_arr); 
        }
       
        return $resultArray;
    }

    function oneAuto($id)
    {
        $resultArray = array();
       
        $stmt = $this->con->prepare("SELECT Cars.id, CarsModel.name, model , year , engin , color, max_speed, price
        FROM Cars,CarsModel WHERE id_name = CarsModel.id  
        AND Cars.id = ?");
        $stmt->execute([$id]); 
        $row = $stmt->fetch();

            $tmp_arr = array(
            'id'=>$row['id'],    
            'modelName'=>$row['name'].":".$row['model'],
            'year'=>$row['year'],
            'engine'=>$row['engin'],
            'color'=>$row['color'],
            'maxspeed'=>$row['max_speed'],
            'price'=>$row['price']);
            array_push($resultArray, $tmp_arr); 
        
        return $resultArray;
    }

    function searchAuto()
    {
        $val = 'BMW';
        $searchParam = 'Name';
        $arr = array();
        foreach($this->con->query('SELECT Cars.id, CarsModel.name, model 
        from Cars,CarsModel 
        where id_name = CarsModel.id') as $row) 
        {
            $tmp_arr = array('id'=>$row['id'],'model'=>$row['model'],'name'=>$row['name']);
            array_push($arr, $tmp_arr); 
        }
       
        return $arr;

        foreach ($this->autoCatalog as $item)
        {
            if($item[$searchParam] == $val)
            {
                $tmp_arr = array(
                    'modelName'=>$item['Name'].":".$item['Model'],
                    'year'=>$item['Year'],
                    'engine'=>$item['Engine'],
                    'color'=>$item['Color'],
                    'maxspeed'=>$item['MaxSpeed'],
                    'price'=>$item['Price']
                );
                array_push($arr, $tmp_arr);    
            }
        }
        return $arr;
    }

}


// class registerUsers {
//   function setData($name, $password, $email, $userType) 
//   {
//       $dbInfo = array(
//           'host' => 'localhost',
//           'user' => 'user11',
//           'pass' => 'user11',
//           'database' => 'user11'
//       );
//       if(empty($name) || empty($password) || empty($email) || empty($userType)) 
//       {
//           throw new SoapFault("Server", "Error! You must send all fields.");
//           exit;
//       }
//       $name = htmlspecialchars(trim($name));
//       $password = md5(htmlspecialchars(trim($password)));
//       $email = htmlspecialchars(trim($email));
//       $userType = htmlspecialchars(trim($userType));
//       $this->connect = new PDO ("mysql:host=localhost;dbname=user1;charset=utf8", 'user11', 'user11') ;
//       $sqlQuery = "INSERT INTO users_soap (name, password, email, userType) VALUES ('$name', '$password', '$email', '$userType')";
//       $result = $this->connect->query($sqlQuery) ;
//       return "Success! All data sent to database!";
//   }
//   function getUsers() {
//       $dbInfo = array(
//           'host' => 'localhost',
//           'user' => 'user11',
//           'pass' => 'user11',
//           'database' => 'user11'
//       );
//       $this->connect = new PDO ("mysql:host=localhost;dbname=user1;charset=utf8", 'user11', 'user11') ;
//       $sqlQuery = "SELECT name, email, userType FROM users_soap";
//       $result = $this->connect->query($sqlQuery);    
      
//       $resultArray = array ();
//   while ($row = $result->fetchAll(PDO::FETCH_OBJ) ) 
//   {
//     $resultArray[] = $row;
//       }
      
//       return $resultArray;
      
//   }
// }



$options= array('uri'=>'/home/user11/public_html/soap/task2/soapserver/');
$options['soap_version'] = SOAP_1_1;
//$options['encoding'] = 'UTF-8';
$options['location'] = '/home/user11/public_html/soap/task2/soapserverserver.php';

//$server = new SoapServer(null, $options));
//$server=new SoapServer(NULL);

// initialize SOAP Server
//$server=new SoapServer("test.wsdl",array(
//    'soap_version' => SOAP_1_1,
//    'style' => SOAP_RPC,
//    'use' => SOAP_LITERAL
//));

//$server->setClass('NewOperation');
// register available functions
//$server->addFunction('hello');
//$server->setClass('MyServer');

// start handling requests
//$server->handle();
//echo 'SOAP server';

$server = new SoapServer('http://tc.geeksforless.net/~user11/soap/task2/soapserver/cars.wsdl');
//$server->addFunction("sayHello");
$server->setClass("AutoShop");
$server->handle();
//var_dump($server);