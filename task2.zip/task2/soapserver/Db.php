<?PHP
include ('dbconfig.php');
class Db
 {
    protected function getConnection()
     {
            $dsn = "mysql:host=" . HOST . 
            ";dbname=" . DB . ";charset=" . CHARSET;
            $user = USER;
            $password = PASSWORD;

        $opt= [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES  => false
        ];

        try{
            $pdo = new PDO($dsn, $user, $password, $opt);
        }
        catch(PDOException $e) 
        {  
            return $e->getMessage();  
        }
        return $pdo;
     }

     function select($query)
     {
        if(!$con = $this->getConnection())
        return false;
        $stmt = $con->prepare($query);
        $stmt->execute();
        $row = $stmt->fetchAll();
        $res = array();
        foreach($row as $r)
        {
            $res[] = $r;
        }
        return $res;
     }

 }