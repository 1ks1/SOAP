<?PHP
class Db
 {
    function getConnection()
     {
            $dsn = "mysql:host=" . HOST . 
            ";dbname=" . DB . ";charset=" . CHARSET;

            $user = USER;
            $password = PASSWORD;

        $opt= [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES  => false
        ];

        try{
            $pdo = new PDO($dsn, $user, $password, $opt);
            print_r('PDO=');
            print_r($pdo);
        }
        catch(PDOException $e) 
        {  
            return $e->getMessage();  
        }
        return $pdo;
     }

 
        //     $this->connect();
        //     $res = array();
        //     if (! $this->pdo == false)
        //     {
                
                
        //         try
        //         {
        //             $stmt = $this->pdo->prepare($this->query);
        //             $stmt->execute();
        //             ///debug////
        //             // $stmt = $this->pdo->query($this->query);
        //             // echo '<hr />';
        //             // print_r($stmt->rowCount());
        //             // echo '<hr />';
        //             // print_r(get_class_methods ($stmt));
        //             ///debug////
        //             $row = $stmt->fetchAll();
        //             foreach($row as $r)
        //             {
        //                 $res[] = $r;
        //             }
        //         }
        //         catch(PDOException $e) 
        //         {  
        //             $errorpdo = $e->getMessage();  
        //         }   
        //             if (isset($errorpdo))
        //             $res = array('Oops! Pdoerr:',$errorpdo);
                    
        //     }else{$res = 'Dude! Pdoconnect error';}
        //     return $res;
        // }

     


 }