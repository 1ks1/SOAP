<?PHP

//server///
//define('URL'.'http://tc.geeksforless.net/~user11/soap/task2/soapserver/cars.wsdl');
define('URL','http://127.0.0.1/SOAP/task2/soapserver/cars.wsdl');

