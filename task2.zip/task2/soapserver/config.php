<?PHP
###################
## server config ##
###################

define('URL','http://tc.geeksforless.net/~user11/soap/task2/soapserver/cars.wsdl');
//define('URL','http://127.0.0.1/SOAP/task2/soapserver/cars.wsdl');
ini_set("soap.wsdl_cache_enabled","0");
ini_set( 'soap.wsdl_cache_ttl', 0 );
date_default_timezone_set('Europe/Kiev');
