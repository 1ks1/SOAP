<?PHP
include('config.php');
include('server.php');
date_default_timezone_set('Europe/Kiev');
//header('Content-Type: text/html; charset=utf-8');
// header('Content-Type: text/html; charset=windos-1254');
// header('Cache-Control: no-store, no-cache');
// header('Expires: '.date('r'));


echo '<h1>test class Server</h1>';
echo '<hr />';

$svr = new AutoShop;

var_dump($svr->searchAuto(['year'=>'2006']));