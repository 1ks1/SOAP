<?PHP
include('server.php');
$db = new Db;
echo '<h1>test class Server</h1>';
echo '<hr />';
print_r($db->getConnection());