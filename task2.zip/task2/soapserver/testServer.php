<?PHP
// include('config.php');
// include('server.php');
include('libs/AutoShop.php');
date_default_timezone_set('Europe/Kiev');
//header('Content-Type: text/html; charset=utf-8');
// header('Content-Type: text/html; charset=windos-1254');
// header('Cache-Control: no-store, no-cache');
// header('Expires: '.date('r'));


echo '<h1>test class Server</h1>';
echo '<hr />';
print_r("<pre>");
$svr = new AutoShop;
$type['year']="2006";
$type['price']="4000";
print_r($svr->searchAuto($type));
//var_dump($svr->allAuto());