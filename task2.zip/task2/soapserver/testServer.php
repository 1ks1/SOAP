<?PHP
//include('config.php');
//include('server.php');
include('libs/dbconfig.php');
//include('libs/Db.php');
include('libs/AutoShop.php');
date_default_timezone_set('Europe/Kiev');
//header('Content-Type: text/html; charset=utf-8');
// header('Content-Type: text/html; charset=windos-1254');
// header('Cache-Control: no-store, no-cache');
// header('Expires: '.date('r'));


echo '<h1>test class Server</h1>';
echo '<hr />';

$svr = new AutoShop;

if ($_POST['searchButton'])
{
    print_r("<pre>");
    print_r($_POST);
    print_r("<br />");
    $error = '';
        $params = [];
        
        if (strlen($_POST['year']) > 1)
        {
            $params['year'] = $_POST['year'];
        } else {
            $error = "<b>Error! Please field year!</b>";
        }
        
        if (strlen($_POST['model']) > 1)
        $params['model'] = $_POST['model'];
        if (strlen($_POST['color']) > 1)
        $params['color'] = $_POST['color'];
        if (strlen($_POST['engine']) > 1)
        $params['engine'] = $_POST['engine'];
        if (strlen($_POST['price']) > 1)
        $params['price'] = $_POST['price'];
        if (strlen($_POST['maxspeed']) > 1)
        $params['maxspeed'] = $_POST['maxspeed'];
        if(0 == strlen($error))
        {
            $a = $svr->searchAuto($params);
        }

    
    print_r($a);
}

?>

<form action="" method="POST">
        <input type="text" name="year" placeholder="year">
        <input type="text" name="model" placeholder="model name">

        <select name="color">
        <option value="0" disabled selected>COLOR</option>
        <option value="1">black</option>
        <option value="2">white</option>
        <option value="3">red</option>
        <option value="4">yellow</option>
        <option value="5">green</option>
        <option value="6">blue</option>
        <option value="7">gray</option>
        <option value="8">orange</option>
        <option value="9">silver</option>
        </select>

        <select name="engine">
        <option value="0" disabled selected>ENGINE</option>
        <option value="1">0 - 1000</option>
        <option value="2">1000 - 2000</option>
        <option value="3">2000 - 3000</option>
        <option value="4">3000 - 4000</option>
        <option value="5">4000 - 5000</option>
        <option value="6">6000 - 6000</option>
        <option value="7">6000 - 7000</option>
        <option value="8">7000 - 8000</option>
        <option value="9">8000 - 9000</option>
        <option value="10">9000 - 10000</option>
        <option value="more">10000 - more</option>
        </select>

        <select name="price" form="searchForm">
        <option value="0" disabled selected>PRICE</option>
        <option value="1">0 - 1000</option>
        <option value="10">1000 - 10000</option>
        <option value="100">10000 - 100000</option>
        <option value="1000">100000 - 1000000</option>
        <option value="10000">1000000 - 10000000</option>
        <option value="more">more</option>
        </select>

        <select name="maxspeed" form="searchForm">
        <option value="0" disabled selected>SPEED</option>
        <option value="1">100</option>
        <option value="2">150</option>
        <option value="3">200</option>
        <option value="4">250</option>
        <option value="5">300</option>
        <option value="6">350</option>
        <option value="7">400</option>
        <option value="more">more</option>
        </select>
        <br /><button type="submit" name="searchButton" value="searchButton">Search Car</button>
    </form>