<?PHP
//define('URL'.'http://tc.geeksforless.net/~user11/soap/task2/soapserver/server.php?WSDL');
define('URL','http://127.0.0.1/SOAP/task2/soapserver/server.php?WSDL');