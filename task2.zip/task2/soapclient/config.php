<?PHP
define('URLWSDL','http://tc.geeksforless.net/~user11/soap/task2/soapserver/server.php?WSDL');
define('URL','http://tc.geeksforless.net/~user11/soap/task2/soapserver/server.php');
define('NS','http://tc.geeksforless.net/~user11/soap/task2/');
// define('URLWSDL','http://127.0.0.1/SOAP/task2/soapserver/server.php?WSDL');
// define('URL','http://127.0.0.1/SOAP/task2/soapserver/server.php');
// define('NS','http://127.0.0.1/SOAP/task2/');
date_default_timezone_set('Europe/Kiev');
header("Content-Type: text/html; charset=utf-8");
header('Cache-Control: no-store, no-cache');
ini_set("soap.wsdl_cache_enabled", 0);