<?PHP
session_start();
include('config.php');
include('libs/Client.php');
$obClient = new Client;
$arr = $obClient->GetCars();

$yr         = '';
$error      = '';
$strInfoCar = '';
$order      = '';
$idCarOrder = '';
$list       = '';

if (!isset($displayOrderForm))
	$displayOrderForm = 'style="display:none;"';

if (isset($_POST['orderData']) && strlen($_POST['orderData']) > 0)
{
    $orderData = $searchData = json_decode($_SESSION['orderData'],true);
}else{
    $orderData = [];
}


if (isset($_POST['clearSearch']) && $_POST['clearSearch'] == 'clearFounds')
{
    unset($_SESSION['SearchList']);
    unset($_SESSION['SearchData']);
}

if (!isset($_SESSION['SearchList']))
$_SESSION['SearchList'] = '';

if (isset($_SESSION['SearchData']))
{
    $searchData = json_decode($_SESSION['SearchData'],true);
    if (isset($searchData['year']))//searching placeholder
    $yr = $searchData['year'];
    if (isset($searchData['model']))//searching placeholder
    $mdlN = $searchData['model'];
    //print_r($searchData);
}else{$searchData = [];}





$list = $obClient->arrayToFormList($arr,'list_all_cars');
if ($_POST)
{
    // print_r($_POST);
    // print_r("<br /><br /><hr/>");
    //get car info by id
    if (isset($_POST['carId']))
    {
        $a = $obClient->GetCarsById((integer)$_POST['carId']);
        $strInfoCar = '<b>Info:</b><br />';
            foreach ($a[0] as $key=>$value)
            {
                $strInfoCar .= "$key: $value <br/>";
            }
    }
    
    if (isset($_POST['searchButton']))
    {
        $params = [];

        if (isset($_POST['year']) && is_numeric($_POST['year']))
        {
            $params['year'] = $_POST['year'];
        } else {
            $error = "<b>Error! Please field year!</b>";
        }

        if (isset($_POST['model']) && strlen($_POST['model']) > 0)
        {
            $_POST['model']     = htmlspecialchars(trim($_POST['model']));
            $params['model']    = $_POST['model'];
        }
        
        if (isset($_POST['color']) && strlen($_POST['color']) > 1)
        $params['color']    = $_POST['color'];
        if (isset($_POST['engine']) && strlen($_POST['engine']) > 1)
        $params['engine']   = $_POST['engine'];
        if (isset($_POST['price']) && strlen($_POST['price']) > 1)
        $params['price']    = $_POST['price'];
        if (isset($_POST['maxspeed']) && strlen($_POST['maxspeed']) > 1)
        $params['maxspeed'] = $_POST['maxspeed'];
        if(0 == strlen($error))
        {
            $a = $obClient->searchCar($params);
            //$idCarOrder = $a['car.id'];
            $list = $obClient->arrayToFormList($a,'list_all_cars');
            $_SESSION['SearchList'] = $list;
            $searchData = $params;
            $_SESSION['SearchData'] = json_encode($params);
        }
    }
    
    if (isset($_POST['orderCar']) )
    {   
        
        $order = 'ORDER!';
        $a = $obClient->GetCarsById((integer)$_POST['orderCar']);
        print_r($a[0]['ID']);
        $idCarOrder = $a[0]['ID'];
        $displayOrderForm = '';
        $order = 'ORDER!';

    }else{
        $displayOrderForm = 'style="display:none;"';
        $order = '';
    }

}

if (isset($searchData['year']))//searching placeholder
$yr = $searchData['year'];
if (isset($searchData['model']))//searching placeholder
$mdlN = $searchData['model'];



if (isset($_SESSION['SearchList']) && strlen($_SESSION['SearchList']) > 5)
$list = $_SESSION['SearchList'] . '<br/><s>Searching!</s><br/>';


include('templates/list.php');