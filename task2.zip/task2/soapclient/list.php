<?PHP
include('config.php');
include('libs/SoapClient.php');
$obClient = new Client;
$arr = $obClient->GetCars();

///generate clickable list///
$list = '';
$list = $obClient->arrayToFormList($arr,'list_all_cars');

$strInfoCar = '';
if($_POST)
{
    //get car info by id
    if ($_POST['carId'])
    {
        $a = $obClient->GetCarsById((integer)$_POST['carId']);
        $strInfoCar = '<b>Info:</b><br />';
            foreach($a[0] as $key=>$value)
            {
                $strInfoCar .= "$key: $value <br/>";
            }

    }

}

include('templates/list.php');