<?PHP
include('config.php');
include('libs/Client.php');
$obClient = new Client;
$arr = $obClient->GetCars();
///generate clickable list///
$list = '';
$list = $obClient->arrayToFormList($arr,'list_all_cars');

$strInfoCar = '';
if ($_POST)
{
    print_r($_POST);
    print_r("<br /><br />");
    //get car info by id
    if (isset($_POST['carId']))
    {
        $a = $obClient->GetCarsById((integer)$_POST['carId']);
        $strInfoCar = '<b>Info:</b><br />';
            foreach ($a[0] as $key=>$value)
            {
                $strInfoCar .= "$key: $value <br/>";
            }
    }

    if (isset($_POST['searchButton']))
    {
        $error = '';
        $params = [];
        
        if (strlen($_POST['year']) > 1)
        {
            $params['year'] = $_POST['year'];
        } else {
            $error = "<b>Error! Please field year!</b>";
        }
        
        if (strlen($_POST['model']) > 1)
        $params['model'] = $_POST['model'];
        if (strlen($_POST['color']) > 1)
        $params['color'] = $_POST['color'];
        if (strlen($_POST['engine']) > 1)
        $params['engine'] = $_POST['engine'];
        if (strlen($_POST['price']) > 1)
        $params['price'] = $_POST['price'];
        if (strlen($_POST['maxspeed']) > 1)
        $params['maxspeed'] = $_POST['maxspeed'];
        if(0 == strlen($error))
        {
            $a = $obClient->searchCar($params);
            //$idCarOrder = $a['car.id'];
            $list = $obClient->arrayToFormList($a,'list_all_cars');
        }
    }
    
    if ( isset($_POST['orderCar']) )
    {   
        $a = $obClient->GetCarsById((integer)$_POST['orderCar']);
        print_r($a[0]['ID']);
        $idCarOrder = $a[0]['ID'];
        $displayOrderForm = '';
        $order = 'ORDER!';
    }


}

include('templates/list.php');