<?PHP 

class Client 
{
    private $client;

    function getClient()
    {
        $url = URL;
        $options['uri'] = NS;
        $options['location'] = URL;
        $options['cache_wsdl'] =  WSDL_CACHE_NONE;
        $options['trace'] = true;
        $options['soap_version'] = SOAP_1_1;
        $client = new SoapClient(URLWSDL,$options);
        $this->client = $client;
        return $client;
    }


    function arrayToTable($arr,$cssClassName)
    {
            if (is_array($arr))
            {
                $t = '<table class="' . 
                $cssClassName . '">' . "\n";
                $f = true;
                foreach($arr as $r)
                {   
                    if ($f)
                    {
                        $t .= '<tr><td>';
                        $t .= implode('</td><td>', array_keys($r));
                        $t .= '</td></tr>';
                        $f = false;
                    }
                    $t .= '<tr><td>';
                    $t .= implode('</td><td>', $r);
                    $t .= '</td></tr>';
                    
                }
                $t .= '</table>';
            } else {
                $t = $arr;
            }

        return $t;
    }


    function arrayToFormList($arr,$className)
    {
        $formList = '<form method="POST" class="' . 
        $className . '">';

        foreach($arr as $k=>$v)
        {
            
            $formList .= '<button type="submit" value="' .
            $v['id'] . '" name="carId">';
            $formList .= $v['id'] . " - " . $v['brand'] . " - "  . $v['model'];
            $formList .= '</button><br />';
        }
        $formList .= '</form>';
        return $formList;
    }


    function GetCars()
    {

            $client = $this->getClient();
            $resp = false;
           
            try 
            {
                $resp  = $client->allAuto();
            } catch (Exception $e) 
            {
                $resp  = $e->getMessage();
                // echo($client->__getLastResponse());
                // echo PHP_EOL;
                // echo($client->__getLastRequest());
            }           
        return $resp;
    }


    function GetCarsById($id)
    {
        if(is_integer($id) && (0 < $id))
        {
            $client = $this->getClient();
            $resp = false;
            try 
            {
                $resp  = $client->oneAuto($id);
            } 
            catch (Exception $e) 
            {
                $resp  = $e->getMessage();
                return $resp;
            }  
            
            return $resp;
        }
        return false;
    }

    function order($user)
    {
        $client = $this->getClient();
        $arr = $client->showOrder($this->valid($user));
        return $arr;
    }

    function valid($text)
    {
      $text = htmlspecialchars($text);
      return strip_tags($text);
    }

    #SEARCH PARAMS
    #params search like array where ['year'=> xxxx] 
    #model - string
    #color - Red,Blue,Green,White and other standart colors
    #engine - value not more of sending numeric. example ['engine'=>1000]
    #price - numeric value. ['price'=>20000] (not more then 20000)
    #maxspeed - numeric value. ['maxspeed'=>200] (not more then 200 km/h)
    function searchCar($type = '')
    {
        $client = $this->getClient();
        $table = '';
        return $client->searchAuto($type);
        //return $client->searchAuto($type);
        
    }

}