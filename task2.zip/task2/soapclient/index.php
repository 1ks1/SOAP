<?php
include('config.php');
include('libs/SoapClient.php');

$obClient = new Client;

$ar = '';
$ar = $obClient->arrayToTable($obClient->GetCars(),'car_all');
$carInfo = '';
$id = 1;
$res = $obClient->GetCarsById($id);
$carInfo = $obClient->arrayToTable($res,'car_info');
 //$obClient->searchCar();
 //function search car///
 // year *
 $params = [];
 $params['year'] = 2008; #!
 $params['model'] = 'X3';
 //$params['engine'] = '3000';
 //$params['maxspeed'] = '100';
 //$params['price'] = '20000';
 $carSerchRes = $obClient->arrayToTable(
     $obClient->searchCar($params),
     'search_res');

//  if ($_POST)
//  print_r($_POST);
$orderTable = '';
 if ((!empty($_POST['user'])) && (2 < strlen($_POST['user'])) )
 {
    $order = $obClient->order($_POST['user']);
    $orderTable = $obClient->arrayToTable($order,'user_order_car');
 } else {
    $orderTable = $obClient->arrayToTable(['0'=>['Error'=>'User name 3 symb min']],'error');
 }


include('templates/index.php');