<?php
include('config.php');
date_default_timezone_set('Europe/Kiev');
//$urlWsdl = 'http://tc.geeksforless.net/~user11/soap/task2/soapserver/server.php?wsdl';


//header("Connection: Keep-Alive");
//header("User-Agent: PHP-SOAP/5.2.9-1");
header("Content-Type: text/html; charset=utf-8");
header('Cache-Control: no-store, no-cache');
ini_set("soap.wsdl_cache_enabled", 0);
//Header("Pragma: no-cache"); // HTTP/1.1 
//header('Expires: '.date('r'));
//ini_set('display_errors', 1);
//error_reporting(E_ALL & ~E_NOTICE);
//$url = URL;
$url = URL;
//$client=new SoapClient($urlWsdl,array( 'soap_version' => SOAP_1_2));
//$url  = "http://tc.geeksforless.net/~user11/soap/task2/soapserver/server.php?WSDL";
//$url  = 'http://www.cbr.ru/DailyInfoWebServ/DailyInfo.asmx?WSDL';
//$options ['location'] = "http://tc.geeksforless.net/~user11/soap/task2/soapserver/server.php";
//$options ['uri'] = "http://tc.geeksforless.net/~user11/soap/task2/soapserver/";
//$options ['soap_version'] = SOAP_1_2;
//$options ['exceptions'] = true;


// $options = array(
// 				'location'=>$url,
// 				'uri'      => "http://tc.geeksforless.net/~user11/soap/task2/soapserver/",
//                 'soap_version'=> SOAP_1_1,
//                 'exceptions'=>true,
//                 'trace'=>1,
//                 'cache_wsdl'=>WSDL_CACHE_NONE
//         );

//$client = new SoapClient(null,$options);

//$client = new SoapClient($url, $options);
//echo $client->getMessage();

//try {
//$resp  = $client->hello();
//} catch (Exception $e) {
//$resp  = $e->getMessage();
//}
//$opt = [	'location'=>'http://tc.geeksforless.net/~user11/soap/task2/soapserver/server.php',
//				'uri'=>'http://tc.geeksforless.net/~user11/soap/task2/soapserver/',
//				'use'=> SOAP_LITERAL,
//				'style'=> SOAP_DOCUMENT,
//				'soap_version'=> SOAP_1_1,
//				'trace' => 1];

//$testUrl = 	'http://webservices.oorsprong.org/websamples.countryinfo/CountryInfoService.wso?WSDL';			
$options['uri'] = "http://127.0.0.1/SOAP/task2/";
$options['location'] = "http://127.0.0.1/SOAP/task2/soapserver/server.php";
$options['cache_wsdl'] =  WSDL_CACHE_NONE;
$options['trace'] = true;
$options['soap_version'] = SOAP_1_1;

$client = new SoapClient(URL,$options);
//var_dump($client->__getFunctions());
try {
$resp  = $client->allAuto();
} catch (Exception $e) {
$resp  = $e->getMessage();
// echo($client->__getLastResponse());
//     echo PHP_EOL;
//     echo($client->__getLastRequest());
}
//var_dump($resp);
//var_dump($client->allAuto());
$ar = '';
foreach($resp as $r)
{
    $ar .= implode(' - ',$r) . '<br />';
}

include('templates/index.php');