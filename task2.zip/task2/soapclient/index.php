<?php

//config
date_default_timezone_set('Europe/Kiev');
//$urlWsdl = 'http://127.0.0.1/SOAP/task2/soapserver/server.php?wsdl';


header("Connection: Keep-Alive");
header("User-Agent: PHP-SOAP/5.2.9-1");
header("Content-Type: text/html; charset=utf-8");
header('SOAPAction: "http://127.0.0.1/SOAP/task2/soapserver/server.php"');
header('Cache-Control: no-store, no-cache');
header('Expires: '.date('r'));
ini_set('display_errors', 1);
error_reporting(E_ALL & ~E_NOTICE);

//$client=new SoapClient($urlWsdl,array( 'soap_version' => SOAP_1_2));
$url  = "http://127.0.0.1/SOAP/task2/soapserver/server.php?WSDL"; 
//$url  = 'http://www.cbr.ru/DailyInfoWebServ/DailyInfo.asmx?WSDL';
//$options ['location'] = "http://127.0.0.1/SOAP/task2/soapserver/server.php";
//$options ['uri'] = "http://127.0.0.1/SOAP/task2/soapserver/";
//$options ['soap_version'] = SOAP_1_2;
//$options ['exceptions'] = true;


$options = array(
				'location'=>$url,
				'uri'      => "http://127.0.0.1/SOAP/task2/",
                'soap_version'=> SOAP_1_1,
                'exceptions'=>true,
                'trace'=>1,
                'cache_wsdl'=>WSDL_CACHE_NONE
        );

//$client = new SoapClient(null,$options);

//$client = new SoapClient($url, $options);
//echo $client->getMessage();

//try {
//$resp  = $client->hello();
//} catch (Exception $e) {
//$resp  = $e->getMessage();
//}
$opt = [	'location'=>'http://127.0.0.1/SOAP/task2/soapserver/server.php',
				'uri'=>'http://127.0.0.1/SOAP/task2/soapserver/',
//				'use'=> SOAP_LITERAL,
//				'style'=> SOAP_DOCUMENT,
//				'soap_version'=> SOAP_1_1,
				'trace' => 1];

$testUrl = 	'http://webservices.oorsprong.org/websamples.countryinfo/CountryInfoService.wso?WSDL';			
$cl = new SoapClient($url);
var_dump($cl->__getFunctions());	
//print_r( $cl->sayHello(array('firstName'=>'Vasilij')) );
print_r( $cl->sayHello(['firstName'=>'Piotr']));