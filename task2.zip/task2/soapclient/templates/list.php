<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
        button{
            background:linear-gradient(#fff,#ccc);
            width:100px;
            border:none;
            border-radius:5px;
            box-shadow: 1px 1px 2px #000;
            margin:2px;
        }
        .list_of_params{
            top:100px;
            right:10px;
            width:700px;
            box-shadow: 1px 1px 4px #ccc;
            margin:15px auto;
        }
        .list_of_cars{
            border-radius:3px;
            top:100px;
            width:50%;
            padding:10px 5px;
            box-shadow: 1px 1px 4px #ccc;
            margin:15px auto;
            float:left auto;
        }
        h1{
            width:100%;
            background:#000;
            color:#fff;
            text-align:left;
        }
        #searchForm input,#searchForm select{
            width:150px;
        }
        .search{
            box-shadow: 1px 1px 4px #ccc;
            text-align:center;
            margin:15px auto;
        }

    </style>
    <title>Cars list</title>
</head>
<body>
    <header class="d-flex justify-content-center">
    <h1>CarShop - List</h1>
    </header>
    <section class="justify-content-center">
        <div class="list_of_cars">
            <?PHP echo $list; ?>
        </div>
        <div class="list_of_params">
            <?PHP echo $strInfoCar; ?>
        </div>
    </section>
    <section>
    <div class="search">
        <form action="" id="searchForm" method="POST">
        <input type="text" name="year" placeholder="year">
        <input type="text" name="model" placeholder="model name">

        <select name="color">
        <option value="0" disabled selected>COLOR</option>
        <option value="1">black</option>
        <option value="2">white</option>
        <option value="3">red</option>
        <option value="4">yellow</option>
        <option value="5">green</option>
        <option value="6">blue</option>
        <option value="7">gray</option>
        <option value="8">orange</option>
        <option value="9">silver</option>
        </select>

        <select name="engine">
        <option value="0" disabled selected>ENGINE</option>
        <option value="1">0 - 1000</option>
        <option value="2">1000 - 2000</option>
        <option value="3">2000 - 3000</option>
        <option value="4">3000 - 4000</option>
        <option value="5">4000 - 5000</option>
        <option value="6">6000 - 6000</option>
        <option value="7">6000 - 7000</option>
        <option value="8">7000 - 8000</option>
        <option value="9">8000 - 9000</option>
        <option value="10">9000 - 10000</option>
        <option value="more">10000 - more</option>
        </select>

        <select name="price" form="searchForm">
        <option value="0" disabled selected>PRICE</option>
        <option value="1">0 - 1000</option>
        <option value="10">1000 - 10000</option>
        <option value="100">10000 - 100000</option>
        <option value="1000">100000 - 1000000</option>
        <option value="10000">1000000 - 10000000</option>
        <option value="more">more</option>
        </select>

        <select name="maxspeed" form="searchForm">
        <option value="0" disabled selected>SPEED</option>
        <option value="1">100</option>
        <option value="2">150</option>
        <option value="3">200</option>
        <option value="4">250</option>
        <option value="5">300</option>
        <option value="6">350</option>
        <option value="7">400</option>
        <option value="more">more</option>
        </select>
        <br /><button type="submit" name="searchButton" value="searchButton">Search Car</button>
        </form>
        <?PHP echo $error; ?>
    </div>
    </section>
    <section>
        <div>
        <?PHP echo $order; ?>
        <form action="" method="POST" style="<?PHP echo $displayOrderForm ?>">
        <input type="text" name="FirstName"><br />
        <input type="text" name="LastName"><br />
        <input type="text" name="Email"><br />
        <input type="text" name="CarId" value="<?PHP echo $idCarOrder ?>"><br />
        <select name="payment">
        <option value="0" disabled selected>PAYMENT</option>
        <option value="1">Card</option>
        <option value="2">Cash</option>
        </select>
        <input type="submit" name="SaveOrder">
        </form>
        </div>
    </section>
</body>
</html>