<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
        button{
            background:linear-gradient(#fff,#ccc);
            width:100%;
            border:none;
            border-radius:5px;
            box-shadow: 1px 1px 2px #000;
            margin:2px;
        }
        .list_of_params{
            top:100px;
            right:10px;
            width:700px;
            box-shadow: 1px 1px 4px #ccc;
            margin:15px auto;
        }
        .list_of_cars{
            border-radius:3px;
            top:100px;
            width:700px;
            padding:10px 5px;
            box-shadow: 1px 1px 4px #ccc;
            margin:15px auto;
            float:left auto;
        }
        h1{
            width:100%;
            background:#000;
            color:#fff;
            text-align:left;
        }

    </style>
    <title>Cars list</title>
</head>
<body>
    <header class="d-flex justify-content-center">
    <h1>CarShop - List</h1>
    </header>
    <section class="justify-content-center">
        <div class="list_of_cars">
            <?PHP echo $list; ?>
        </div>
        <div class="list_of_params">
            <?PHP echo $strInfoCar; ?>
        </div>
    </section>
</body>
</html>