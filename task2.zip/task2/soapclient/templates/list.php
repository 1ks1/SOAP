<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
        body{
            background:url(https://img1.liveinternet.ru/images/attach/c/1//60/146/60146306_1276185328_53845815_h123.gif);
            height:1500px;
        }
        button{
            background:linear-gradient(#ccc,#888,#000);
            color:#ffa;
            width:100px;
            border:none;
            border-radius:5px;
            box-shadow: 1px 1px 2px #000;
            margin:2px;
        }

        .list_of_params{
            top:100px;
            right:10px;
            width:700px;
            box-shadow: 1px 1px 4px #ccc;
            margin:15px auto;
        }
        .list_of_cars{
            border-radius:3px;
            top:100px;
            width:50%;
            padding:10px 5px;
            box-shadow: 1px 1px 4px #ccc;
            margin:50px auto;
            float:left auto;
        }
        h1{
            position:fixed;
            width:100%;
            background:RGBA(0,0,0,.5);
            color:RGBA(254,254,254,.9);
            text-align:left;
        }
        #searchForm input,#searchForm select{
            width:150px;
            height:25px;
            background:linear-gradient(#000,#000,#aaa);
            color:#fff;
            font-size:12px;
            font-family:Verdana,Arial;
            border:#ccc;
            border-radius:4px;
        }
        .search{
            box-shadow: 1px 1px 4px #ccc;
            text-align:center;
            margin:15px auto;
        }

        .order{
            box-shadow: 1px 1px 4px #ccc;
            text-align:center;
            margin:15px auto;
        }

    </style>
    <title>Cars list</title>
</head>
<body>
    <header class="d-flex justify-content-center">
    <h1>CarShop - List</h1>
    </header>
    <section class="justify-content-center">
        <div class="list_of_cars">
            <?PHP echo $list; ?>
        </div>
        <div class="list_of_params">
            <?PHP echo $strInfoCar; ?>
        </div>
    </section>
    <section>
    <div class="search">
        <form action="" id="searchForm" method="POST">
        <input type="text" name="year" placeholder="year" value="<?PHP echo $yr;?>">
        <input type="text" name="model" placeholder="model name">

        <select name="color">
        <option value="-1" disabled selected>COLOR</option>
        <option value="black">black</option>
        <option value="white">white</option>
        <option value="red">red</option>
        <option value="yellow">yellow</option>
        <option value="green">green</option>
        <option value="blue">blue</option>
        <option value="gray">gray</option>
        <option value="orange">orange</option>
        <option value="silver">silver</option>
        </select>

        <select name="engine">
        <option value="-1" disabled selected>ENGINE</option>
        <option value="1000">0 - 1000</option>
        <option value="2000">1000 - 2000</option>
        <option value="3000">2000 - 3000</option>
        <option value="4000">3000 - 4000</option>
        <option value="5000">4000 - 5000</option>
        <option value="6000">5000 - 6000</option>
        <option value="7000">6000 - 7000</option>
        <option value="8000">7000 - 8000</option>
        <option value="9000">8000 - 9000</option>
        <option value="10000">9000 - 10000</option>
        <option value="0">10000 - more</option>
        </select>

        <select name="price" form="searchForm">
        <option value="-1" disabled selected>PRICE</option>
        <option value="1">0 - 1000</option>
        <option value="10">1000 - 10000</option>
        <option value="100">10000 - 100000</option>
        <option value="1000">100000 - 1000000</option>
        <option value="10000">1000000 - 10000000</option>
        <option value="0">more</option>
        </select>

        <select name="maxspeed" form="searchForm">
        <option value="-1" disabled selected>SPEED</option>
        <option value="1">100</option>
        <option value="2">150</option>
        <option value="3">200</option>
        <option value="4">250</option>
        <option value="5">300</option>
        <option value="6">350</option>
        <option value="7">400</option>
        <option value="0">more</option>
        </select>
        <br /><button type="submit" name="searchButton" value="searchButton">Search Car</button>
        <button type="submit" value="clearFounds" name="clearSearch">Clear</button>
        </form>
        <?PHP echo $error; ?>
    </div>
    </section>
    <section <?PHP echo $displayOrderForm ?>>
        <div class="order">
        <?PHP echo $order; ?>
        <form action="" method="POST">
        <input type="text" name="FirstName" placeholder="FirstName"><br />
        <input type="text" name="LastName" placeholder="LastName"><br />
        <input type="text" name="Email" placeholder="Email"><br />
        Car ID:<br />
        <input type="text" name="CarId" value="<?PHP echo $idCarOrder ?>"><br />
        <select name="payment">
        <option value="0" disabled selected>PAYMENT</option>
        <option value="1">Card</option>
        <option value="2">Cash</option>
        </select>
        <button type="submit" name="SaveOrder">GO!</button>
        </form>
        </div>
    </section>
</body>
</html>