<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CarsShop</title>
<style>
table{
background:#ddd;
border-collapse: collapse;
border: 2px solid RGBA(0,0,0,.0);
box-shadow:1px 2px 3px #000;
}
td {
    border: 1px solid maroon; 
    text-align: left; 
}
</style>
</head>
<body>
<h3>Class Client</h3>
<hr />
1)получить список автомобилей (возвращает только ID, марку и модель)<br />
<b>function allCars()</b><br />
<?PHP echo $ar; ?>
<hr />
2)получить детальную информацию по ID (возвращает комплекс type из<br />
имени модели, год выпуска, объём двигателя, цвет, макс скорость, цена)<br />
<b>function oneAuto(1)</b><br />
<?PHP echo $carInfo; ?>
<hr />
2)поиск по параметрам (в качестве параметров используется тот же <br />
комплекс type что и в предыдущем запросе. <br />
Поле «год выпуска» - обязательно)<br />
<b>function searchCar($params)</b><br />
<?PHP echo $carSerchRes; ?>
<hr />
<a href="http://127.0.0.1/SOAP/task2/task2.txt">текст задания</a>
</body>
</html>