<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CarsShop</title>
<style>
body{
    margin:0;
    padding:0;
}
table{
background:#ddd;
border-collapse: collapse;
border: 2px solid RGBA(0,0,0,.0);
box-shadow:1px 2px 3px #000;
}
.error{color:white;background:red;}
form{
background:#eef;
box-shadow:1px 2px 3px #ccc;
}
td {
    border: 1px solid maroon; 
    text-align: left; 
}
</style>
</head>
<body>
<h3>Class Client</h3>
<hr />
- получить список автомобилей (возвращает только ID, марку и модель) 
<b>function allCars()</b><br />
<?PHP echo $ar; ?>
<hr />
- получить детальную информацию по ID (возвращает комплекс type из
имени модели, год выпуска, объём двигателя, цвет, макс скорость, цена) <br />
<b>function oneAuto(1)</b><br />
<?PHP echo $carInfo; ?>
<hr />
- поиск по параметрам (в качестве параметров используется тот же 
комплекс type что и в предыдущем запросе. <br />
Поле «год выпуска» - обязательно)<br />
<b>function searchCar($params)</b><br />
<?PHP echo $carSerchRes; ?>
<hr />
- функция выполнения предварительного заказа автомобиля (ID авто,
имя, фамилия покупателя, способ оплаты. Способ оплаты enumeration из 
"кредитная карта", "наличные")<br />
<form action="" method="POST">
<br />Example:<br /> Vasilij<br />
User:
<input type="text" name="user" placeholder="Vasilij"><br />
<input type="submit" value="OK"><button disabled>GET ORDER</button>
</form>
<br />
<?PHP echo $orderTable; ?>
<a href="http://127.0.0.1/SOAP/task2/task2.txt">текст задания</a>
</body>
</html>