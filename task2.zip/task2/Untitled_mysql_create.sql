CREATE TABLE `Cars` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`model` varchar(254) NOT NULL,
	`maxspeed` varchar(254) NOT NULL,
	`engine` INT(11) NOT NULL,
	`color_id` INT(11) NOT NULL,
	`brand_id` INT(11) NOT NULL,
	`year` INT(11) NOT NULL,
	`price` INT(11) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `Users` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`name` varchar(254) NOT NULL,
	`lastname` varchar(254) NOT NULL,
	`email` varchar(254) NOT NULL UNIQUE,
	PRIMARY KEY (`id`)
);

CREATE TABLE `Orders` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`payment_id` INT(11) NOT NULL,
	`user_id` INT(11) NOT NULL,
	`car_id` INT(11) NOT NULL,
	`count` INT(11) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `Payments` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`payment` varchar(254) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `Colors` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`color` varchar(255) NOT NULL UNIQUE,
	PRIMARY KEY (`id`)
);

CREATE TABLE `Brends` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`brend` varchar(255) NOT NULL UNIQUE,
	PRIMARY KEY (`id`)
);

ALTER TABLE `Cars` ADD CONSTRAINT `Cars_fk0` FOREIGN KEY (`color_id`) REFERENCES `Colors`(`id`);

ALTER TABLE `Orders` ADD CONSTRAINT `Orders_fk0` FOREIGN KEY (`payment_id`) REFERENCES `Payments`(`id`);

ALTER TABLE `Orders` ADD CONSTRAINT `Orders_fk1` FOREIGN KEY (`user_id`) REFERENCES `Users`(`id`);

ALTER TABLE `Orders` ADD CONSTRAINT `Orders_fk2` FOREIGN KEY (`car_id`) REFERENCES `Cars`(`id`);

ALTER TABLE `Brends` ADD CONSTRAINT `Brends_fk0` FOREIGN KEY (`brend`) REFERENCES `Cars`(`brand_id`);

