<?PHP
class SOAP
{
    public $url;
    public $client;
    public $date;
    public $result;
    public $euro_to;
    public $euro_from;
    public $one_uan_of_ru;

    function __construct($url)
    {
        $this->client = new SoapClient( 
            $url,
            array( 'soap_version'=> SOAP_1_2, 
            'exceptions'=>true));

        $this->date = $this->client->GetLatestDateTime();
        $this->result = $this->client->GetCursOnDateXML(array('On_date'=>$this->date->GetLatestDateTimeResult));
    }
    

    function test()
    {
        if ($this->result->GetCursOnDateXMLResult->any) 
        {
            $xml = new SimpleXMLElement($this->result->GetCursOnDateXMLResult->any);
            foreach ($xml->ValuteCursOnDate as $currency) 
            {
                print_r($currency->VchCode . "<br />");
                echo $currency->Vcurs . "<br />";
                echo $currency->Vnom . "<br />";
                echo "------";
                if ($currency->VchCode=='EUR') 
                {
                    $this->euro_to = floatval($currency->Vcurs);
                    $this->euro_from = $currency->Vnom;
                }
            }
            if ($this->euro_to!=0) 
            { 
                return ($this->euro_to/$this->euro_from);
                // здесь можно вставить код, который обновляет данные в магазине
            }

        }
        else return false;
    }

    function getONEUANEURUSD()
    {
        $eu;
        $us;
        $zl;
        $result = $this->client->GetCursOnDateXML(array('On_date'=>$this->date->GetLatestDateTimeResult));
        if ($result->GetCursOnDateXMLResult->any) 
        {
            $xml = new SimpleXMLElement($result->GetCursOnDateXMLResult->any);
            foreach ($xml->ValuteCursOnDate as $currency) 
            {
                if ($currency->VchCode == 'UAH') 
                {
                    $a = floatval($currency->Vcurs);
                    $b = $currency->Vnom;
                    $this->one_uan_of_ru = ($currency->Vcurs/$currency->Vnom);
                }

                if ($currency->VchCode == 'PLN') 
                {
                    $a = floatval($currency->Vcurs);
                    $b = $currency->Vnom;
                    $zl = ($currency->Vcurs/$currency->Vnom);
                }

                if ($currency->VchCode == 'EUR') 
                {
                    $a = floatval($currency->Vcurs);
                    $b = $currency->Vnom;
                    $eu = ($currency->Vcurs/$currency->Vnom);
                }

                if ($currency->VchCode == 'USD') 
                {
                    $a = floatval($currency->Vcurs);
                    $b = $currency->Vnom;
                    $us = $a/$b;

                    //гривну разделить на курс рубля и умножить на бакс
                    //$us = floatval((1/$this->one_uan_of_ru) * $c);
                }
            }
            return "1 RUB = " . 
            round(1/$this->one_uan_of_ru,2) . "UAH <br /> 1 USD = " . 
            round($us/$this->one_uan_of_ru,2) . "UAH<br /> 1 EUR  " . 
            round($eu/$this->one_uan_of_ru,2) . " UAH <br />" . 
            "1 PLN = " . round($zl/$this->one_uan_of_ru,2) . "UAH";
        }
        else return false;
    }
}