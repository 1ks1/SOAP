<?PHP
include('libs/SOAP.php');
$cl = new SOAP('http://www.cbr.ru/DailyInfoWebServ/DailyInfo.asmx?WSDL');
$cours = $cl->getONEUANEURUSD();
include('templates/index.php');