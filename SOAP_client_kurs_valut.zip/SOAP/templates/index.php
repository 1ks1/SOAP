<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
<h1>Курс валют по РФ</h1>
<?PHP
echo $cours;
?>	
<br /><br /><br />SOAP server www.cbr.ru<br />
<pre>
© Банк России, 2000–2019
Адрес: ул. Неглинная, 12, Москва, 107016

Телефоны: 8 800 300-30-00 (для бесплатных звонков из регионов России),
+7 499 300-30-00 (круглосуточно), факс: +7 495 621-64-65
</pre>
</body>
</html>