<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body><span>for my self. home work</span><hr />
<h1>Курс валют по РФ</h1>

<?PHP
echo $cours;
?>	
<br /><br /><br />SOAP server www.cbr.ru<br />
<hr />
<h2>Task1</h2>
<h3>Class: SoapTest - XML/WSDL</h3><br/>
<?PHP
	foreach($data as $d)
	{
		echo "<img src=" . $d->FullCountryInfoResult->sCountryFlag . 
		" alt=\"flag\" width=\"25px\" /> - ";
		echo ( $d->FullCountryInfoResult->sName . " <br /> " );	
	}
?>
<hr />
By cURL:<br />
<img src="<?PHP echo $flagUrl;?>" alt="img" width="25px" />
</body>
</html>