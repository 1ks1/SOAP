<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<style>
		body{margin:0;padding:0;}
		a,a:visited{text-decoration:none;} 
		a:hover{text-decoration:underline;}
		.home_mate h1,home_mate h2,home_mate h3{text-shadow:0 0 2px #000;}
		.Task1 {text-align:center;}
		.flags{text-align:left;width:250px;border-radius:3px;margin: auto;box-shadow:1px 1px 3px #000;}
	</style>
</head>
<body>

<section>
	<div class="home_mate">
		<span>for my self. home work</span><hr />
		<h1>Курс валют по РФ</h1>
		<?PHP
		echo $cours;
		?>	
		<br /><br /><br />SOAP server www.cbr.ru<br />
		<hr />
	</div>
</section>

<section>
	<div class="Task1">
		<h2>Task1</h2>
		
		<h5>Class: SoapTest - XML/WSDL</5>
			<div class="flags">
				<?PHP
					foreach($data as $d)
					{
						echo "<img src=" . $d->FullCountryInfoResult->sCountryFlag . 
						" alt=\"flag\" width=\"25px\" /> - ";
						echo ( $d->FullCountryInfoResult->sName . " <br /> " );	
					}
				?>
			</div>
			
		<a href="http://webservices.oorsprong.org/websamples.countryinfo/CountryInfoService.wso" target="_blank">webservices.oorsprong.org</a>
		
		<hr />
		By cURL:<br />
		<img src="<?PHP echo $flagUrl;?>" alt="img" width="25px" />
	</div>
</section>

</body>
</html>