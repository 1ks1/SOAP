<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>REST</title>
</head>
<body>
	<?PHP echo  __DIR__  . "<br />"; ?>
	<?PHP print_r("<a href=\" http://127.0.0.1/REST/Server/api/\">API</a>"); ?>
	http://seasonvar.ru/serial-23-Zvezdnie_vrata-7-season.html
</body>
</html>