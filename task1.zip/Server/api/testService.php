<?PHP 
include ('shop/libs/Service.php');

$cl = new Service;
print_r($cl->postLogin(['password'=>'12345678',
'email'=>'test@gmail.com'
]));