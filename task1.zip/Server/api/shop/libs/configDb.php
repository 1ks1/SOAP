<?PHP 
define ('DBTYPE' , '1'); //1 - mysql, 2 - pgsql

define ('DB','user11');
define ('HOST','127.0.0.1');
define ('USER','root');
define ('PASSWORD','usbw');
define ('CHARSET','UTF8');
//define ('USER','user11');
//define ('PASSWORD','user11');
///PG//////////////////////////
define ('PDB','user11');
define ('PHOST','127.0.0.1');
define ('PUSER','root');
define ('PPASSWORD','toor');
define('PPORT','5432');