<?PHP
class SoapTest 
{
    public $url;
    public $params;
    public $client;

    //parametr is optional
    function test($url,$parametr = false)
    {
        if (!$parametr)
        {
            $this->params = '';
        }
        else
        {
            $this->params = $parametr;
            $client = new SoapClient($url);
            $c = count($parametr);
                foreach($this->params as $p)
                {
                    $data[] = $client->FullCountryInfo($p);
                }
        }

        return $data;
    }


    function test2($url,$parametr = false)
    {
        if (!$parametr)
        {
            $this->params = '<sCountryISOCode>string</sCountryISOCode>';
        }

        if (isset($parametr['sCountryISOCode']))
        {
            $this->params = '<sCountryISOCode>' . $parametr['sCountryISOCode'] . '</sCountryISOCode>';
        } 

        $xml_post_string = '<?xml version="1.0" encoding="utf-8"?>
        <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
        <soap:Body>
            <CountryFlag xmlns="http://www.oorsprong.org/websamples.countryinfo">
                ' . $this->params . '
            </CountryFlag>
        </soap:Body>
        </soap:Envelope>';


        $headers = array(
                'Content-Type: text/xml; charset=utf-8',
                'Accept: text/xml',
                'Cache-Control: no-cache',
                'Pragma: no-cache',
                'SOAPAction: ' . 'http://www.oorsprong.org/websamples.countryinfo', 
                "Content-length: ".strlen($xml_post_string),
            ); 
            
       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string); // the SOAP request
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch); 
        curl_close($ch);
        
        $json  = json_encode($response);
        $configData = json_decode($json, true);
        return $configData;
    }


}