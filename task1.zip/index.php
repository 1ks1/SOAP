<?PHP
include('libs/SOAP.php');
include('libs/SoapTest.php');

///just for my self
$cl = new SOAP('http://www.cbr.ru/DailyInfoWebServ/DailyInfo.asmx?WSDL');
$cours = $cl->getONEUANEURUSD();



///FOR TASK1//////////////////////
$cltest = new SoapTest;
$url = 'http://webservices.oorsprong.org/websamples.countryinfo/CountryInfoService.wso?WSDL';
$paramArr = [];
$param [] = ['sCountryISOCode'=>'US'];
$param [] = ['sCountryISOCode'=>'RU'];
$param [] = ['sCountryISOCode'=>'UA'];
$param [] = ['sCountryISOCode'=>'JP'];
$param [] = ['sCountryISOCode'=>'PL'];
$data = $cltest->test($url,$param);

///////////CURL///////////////
$response = $cltest->test2($url,['sCountryISOCode'=>'UA']);
$response = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $response);
$xml = new SimpleXMLElement($response);
$array = json_decode(json_encode((array)$xml), TRUE); 
$flagUrl = $array['soapBody']["mCountryFlagResponse"]["mCountryFlagResult"];


include('templates/index.php');